import 'package:flutter/material.dart';
import 'package:e_book_app/app.dart';

void main() {
  runApp(const MyApp());
}
